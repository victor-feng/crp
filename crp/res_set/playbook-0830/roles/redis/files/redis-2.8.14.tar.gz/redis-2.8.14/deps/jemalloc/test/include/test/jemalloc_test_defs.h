/* test/include/test/jemalloc_test_defs.h.  Generated from jemalloc_test_defs.h.in by configure.  */
#include "jemalloc/internal/jemalloc_internal_defs.h"

/* For use by SFMT. */
#define HAVE_SSE2 
/* #undef HAVE_ALTIVEC */
